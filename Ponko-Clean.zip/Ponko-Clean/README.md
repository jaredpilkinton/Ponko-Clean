# PONKO-CLEAN™

Automatic watch-cleaning machine project based on the Raspberry Pi Pico / RP2040.

## Project status

The mechanical/electrical/control concept is settled; physical fabrication and final assembly remain. The recovered source currently included in this repository is the earlier **UI/demo firmware**. It drives the ST7735 display, rotary encoder and buzzer, but **does not drive the motor**. It is preserved here rather than presenting an unverified reconstruction as the final controller firmware.

## Intended hardware

- Raspberry Pi Pico / RP2040
- BTS7960 H-bridge motor driver
- 12 V DC reversible motor, approximately 300 RPM
- 12 V to 5 V buck converter
- ST7735S 160×128 SPI TFT, landscape / 90° clockwise
- Rotary encoder
- Green OK button
- Red E-Stop / Back button
- Piezo buzzer
- Four jar/basket positions: three solution jars plus one empty spin position

## Intended cleaning sequence

1. Zepride cleaning solution
2. Empty spin
3. Water rinse
4. Empty spin
5. Alcohol rinse
6. Empty spin

The final control concept includes motor ramp-up/ramp-down, default clockwise rotation, optional oscillation, programmable CW/CCW intervals, per-step timing/RPM, pauses prompting the operator to change jars, completion chimes, calibration, manual mode, quick modes, and fault handling.

## Repository contents

- `firmware/ui-demo/main.py` — recovered working UI/demo source; motor control is explicitly absent.
- `docs/HARDWARE.md` — known hardware and recovered UI-demo pinout.
- `docs/CONTROL-SPEC.md` — settled intended controller/UI behavior.
- `docs/STATUS.md` — what is recovered versus what still needs to be committed.
- `.gitignore`

## Important

Do not treat `firmware/ui-demo/main.py` as the final motor-control firmware. The later full controller source was not present in the recovered project file set when this repository package was assembled.
