from machine import Pin, SPI
from time import sleep_ms, ticks_ms, ticks_diff
import framebuf

# ============================================================
# PONKO-CLEAN
# Raspberry Pi Pico / RP2040
# 1.8" ST7735 TFT, 160x128 landscape
#
# GP0  = Active buzzer via transistor
# GP10 = Encoder S1
# GP11 = Encoder S2
# GP12 = Encoder KEY
#
# TFT:
# GP17 = CS
# GP18 = SCK
# GP19 = MOSI / SDA
# GP20 = RESET
# GP21 = DC
#
# splash file:
# ponko_splash_rgb565.bin
#
# Motor is NOT controlled in this version.
# ============================================================

WIDTH = 160
HEIGHT = 128

buzzer = Pin(0, Pin.OUT)
buzzer.off()

def beep(on_ms, off_ms=0):
    buzzer.on()
    sleep_ms(on_ms)
    buzzer.off()
    if off_ms:
        sleep_ms(off_ms)

def startup_warble():
    beep(130, 100)
    for delay in (18, 15, 12, 10, 8, 7):
        buzzer.on(); sleep_ms(delay); buzzer.off(); sleep_ms(delay)
    sleep_ms(35)
    for delay in (10, 8, 6, 5):
        buzzer.on(); sleep_ms(delay); buzzer.off(); sleep_ms(delay)
    buzzer.off()
    sleep_ms(100)

s1 = Pin(10, Pin.IN, Pin.PULL_UP)
s2 = Pin(11, Pin.IN, Pin.PULL_UP)
key = Pin(12, Pin.IN, Pin.PULL_UP)
last_s1 = s1.value()

def encoder_step():
    global last_s1
    current_s1 = s1.value()
    if current_s1 != last_s1:
        if current_s1 == 0:
            if s2.value() != current_s1:
                direction = 1
            else:
                direction = -1
            last_s1 = current_s1
            return direction
        last_s1 = current_s1
    return 0

def button_pressed():
    if key.value() == 0:
        sleep_ms(20)
        if key.value() == 0:
            while key.value() == 0:
                sleep_ms(5)
            sleep_ms(30)
            return True
    return False

spi = SPI(0, baudrate=20_000_000, polarity=0, phase=0, sck=Pin(18), mosi=Pin(19))
cs = Pin(17, Pin.OUT, value=1)
rst = Pin(20, Pin.OUT, value=1)
dc = Pin(21, Pin.OUT, value=0)

def cmd(c, data=None):
    cs.value(0); dc.value(0); spi.write(bytes([c]))
    if data is not None:
        dc.value(1); spi.write(data)
    cs.value(1)

def init_display():
    rst.value(0); sleep_ms(100); rst.value(1); sleep_ms(150)
    cmd(0x01); sleep_ms(150)
    cmd(0x11); sleep_ms(150)
    cmd(0xB1, b'\x01\x2C\x2D'); cmd(0xB2, b'\x01\x2C\x2D')
    cmd(0xB3, b'\x01\x2C\x2D\x01\x2C\x2D'); cmd(0xB4, b'\x07')
    cmd(0xC0, b'\xA2\x02\x84'); cmd(0xC1, b'\xC5'); cmd(0xC2, b'\x0A\x00')
    cmd(0xC3, b'\x8A\x2A'); cmd(0xC4, b'\x8A\xEE'); cmd(0xC5, b'\x0E')
    cmd(0x36, b'\x60')
    cmd(0x3A, b'\x05')
    cmd(0x29); sleep_ms(100)

buffer = bytearray(WIDTH * HEIGHT * 2)
fb = framebuf.FrameBuffer(buffer, WIDTH, HEIGHT, framebuf.RGB565)

def color565(r, g, b):
    return (((r & 0xF8) << 8) | ((g & 0xFC) << 3) | (b >> 3))

BLACK=color565(0,0,0); WHITE=color565(255,255,255); GREEN=color565(0,255,80)
DARKGREEN=color565(0,80,30); GRAY=color565(100,100,100); RED=color565(255,40,30)
CYAN=color565(0,220,255)

def show():
    cmd(0x2A, b'\x00\x00\x00\x9F'); cmd(0x2B, b'\x00\x00\x00\x7F'); cmd(0x2C)
    cs.value(0); dc.value(1)
    chunk = bytearray(512)
    for start in range(0, len(buffer), 512):
        size = min(512, len(buffer)-start)
        for i in range(0, size, 2):
            chunk[i] = buffer[start+i+1]; chunk[i+1] = buffer[start+i]
        spi.write(memoryview(chunk)[:size])
    cs.value(1)

def show_splash():
    cmd(0x2A, b'\x00\x00\x00\x9F'); cmd(0x2B, b'\x00\x00\x00\x7F'); cmd(0x2C)
    cs.value(0); dc.value(1)
    try:
        with open("ponko_splash_rgb565.bin", "rb") as f:
            while True:
                data = f.read(1024)
                if not data: break
                spi.write(data)
    except OSError:
        cs.value(1); fb.fill(BLACK)
        fb.text("SPLASH FILE",32,45,RED); fb.text("NOT FOUND",44,62,WHITE)
        show(); sleep_ms(1500); return
    cs.value(1)

def diagnostics():
    fb.fill(BLACK); fb.rect(3,3,154,122,GREEN)
    fb.text("PONKO-CLEAN",40,10,WHITE); fb.hline(15,24,130,GREEN)
    fb.text("SYSTEM DIAGNOSTIC",12,37,GREEN); show(); sleep_ms(180)
    for label,y in (("CPU",59),("DISPLAY",75),("CONTROLS",91)):
        fb.text(label,24,y,GRAY); show(); sleep_ms(120)
        fb.text("OK",118,y,GREEN); show(); beep(14)
    sleep_ms(180); fb.text("READY",60,109,WHITE); show(); beep(45); sleep_ms(600)

menu_item=0; editing=False; speed=50; run_time=5; MENU_COUNT=3

def draw_menu():
    fb.fill(BLACK); fb.rect(3,3,154,122,GREEN)
    fb.text("PONKO-CLEAN",40,9,WHITE); fb.hline(12,22,136,GREEN)
    if menu_item == 0: fb.text(">",10,37,GREEN)
    fb.text("SPEED",25,37,WHITE); fb.text(str(speed)+"%",105,37,GREEN)
    if menu_item == 1: fb.text(">",10,57,GREEN)
    fb.text("TIME",25,57,WHITE); fb.text(str(run_time)+" MIN",97,57,GREEN)
    if menu_item == 2: fb.text(">",10,77,GREEN)
    fb.text("START",25,77,WHITE); fb.hline(12,96,136,DARKGREEN)
    if editing: fb.text("TURN TO ADJUST",25,105,GREEN)
    else: fb.text("PRESS TO SELECT",20,105,GRAY)
    show()

spinner=[(0,-12),(8,-8),(12,0),(8,8),(0,12),(-8,8),(-12,0),(-8,-8)]

def draw_process_frame(frame, progress):
    fb.fill(BLACK); fb.rect(3,3,154,122,GREEN)
    fb.text("PROCESS RUNNING",20,9,WHITE); fb.hline(12,22,136,GREEN)
    cx=45; cy=60
    fb.rect(cx-19,cy-19,39,39,GRAY); fb.rect(cx-15,cy-15,31,31,DARKGREEN)
    px,py=spinner[frame%len(spinner)]
    fb.line(cx,cy,cx+px,cy+py,GREEN); fb.line(cx,cy,cx-px,cy-py,GREEN)
    px2,py2=spinner[(frame+2)%len(spinner)]
    fb.line(cx,cy,cx+px2,cy+py2,DARKGREEN); fb.line(cx,cy,cx-px2,cy-py2,DARKGREEN)
    fb.fill_rect(cx-2,cy-2,5,5,WHITE)
    bubble=frame%8
    fb.pixel(19,44+(bubble//2),CYAN); fb.rect(65,47-(bubble//2),2,2,CYAN)
    fb.rect(22,80-(bubble//3),3,3,CYAN); fb.pixel(69,76+(bubble//2),CYAN)
    fb.text("SPEED",88,38,GRAY); fb.text(str(speed)+"%",120,51,GREEN)
    fb.text("TIME",88,67,GRAY); fb.text(str(run_time)+"m",120,80,WHITE)
    fb.rect(14,101,132,10,GRAY)
    fill_width=int(128*progress/100)
    if fill_width>0: fb.fill_rect(16,103,fill_width,6,GREEN)
    fb.text(str(progress)+"%",64,115,WHITE); show()

def run_demo_process():
    beep(30,30); beep(80)
    duration_ms=10000; start=ticks_ms(); frame=0
    while True:
        elapsed=ticks_diff(ticks_ms(),start)
        if elapsed>=duration_ms: break
        progress=int(elapsed*100/duration_ms)
        draw_process_frame(frame,progress); frame+=1
        if button_pressed():
            beep(100); fb.fill(BLACK); fb.rect(3,3,154,122,RED)
            fb.text("PROCESS ABORTED",20,50,RED); fb.text("RETURNING...",32,70,WHITE)
            show(); sleep_ms(1000); return
        sleep_ms(60)
    draw_process_frame(frame,100); sleep_ms(300)
    fb.fill(BLACK); fb.rect(3,3,154,122,GREEN)
    fb.text("PONKO-CLEAN",40,14,WHITE); fb.hline(20,28,120,GREEN)
    fb.text("PROCESS",52,49,GRAY); fb.text("COMPLETE",48,67,GREEN)
    fb.text("READY",60,97,WHITE); show()
    beep(30,35); beep(30,35); beep(100); sleep_ms(1800)

init_display(); startup_warble(); show_splash(); sleep_ms(1800); diagnostics(); draw_menu()

while True:
    movement=encoder_step()
    if movement != 0:
        if editing:
            if menu_item == 0:
                speed += movement*5
                if speed<10: speed=10
                if speed>100: speed=100
            elif menu_item == 1:
                run_time += movement
                if run_time<1: run_time=1
                if run_time>30: run_time=30
        else:
            menu_item += movement
            if menu_item<0: menu_item=MENU_COUNT-1
            if menu_item>=MENU_COUNT: menu_item=0
        draw_menu(); beep(7)
    if button_pressed():
        beep(16)
        if menu_item == 0 or menu_item == 1:
            editing = not editing
            draw_menu()
        elif menu_item == 2:
            run_demo_process()
            draw_menu()
    sleep_ms(1)
