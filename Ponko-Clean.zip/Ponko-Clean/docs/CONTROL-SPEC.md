# Intended Control Specification

## Main menu
- Program 1
- Program 2
- Program 3
- Quick 35 RPM
- Quick 300 RPM
- Manual
- Calibration

## Program steps
Programs expose Steps 1–4 with per-step settings:
- Enabled
- Cycle Time (15-second increments)
- RPM
- Oscillate
- CW interval
- CCW interval
- Chime

## Manual mode
- Run / Stop
- RPM
- Oscillate
- CW interval
- CCW interval
- Exit

## Operating behavior
- Default direction: CW
- Ramp motor up/down rather than abrupt starts/stops
- Pause between solution stages with a `change jars` prompt
- Green button: OK/confirm
- Red button: E-Stop / Back
- Startup chirp
- Completion chime

## Cleaning workflow
Zepride → empty spin → water → empty spin → alcohol → empty spin.

## Fault messages
- E-STOP
- CYCLE INTERRUPTED
- CONFIGURATION ERROR
- CONTROLLER ERROR

## Calibration
Calibration is a first-class menu function. The established UI concept includes a clipboard-style CALIBRATION graphic.

## Graphics / branding
PONKO-CLEAN branding uses the green Ponko dinosaur motif. Established UI artwork concepts include:
- Ponko splash: green dinosaur with apron/brush
- Basket graphic
- Clipboard CALIBRATION graphic
- Tantrum/failure graphic
