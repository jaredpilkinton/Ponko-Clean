# Project Status

## Settled
- RP2040/Pico controller architecture
- BTS7960 motor-driver architecture
- 12 V motor / 5 V logic power arrangement
- ST7735S display
- Rotary encoder UI
- OK and E-Stop/Back controls
- Program/manual/calibration menu concept
- Cleaning sequence
- Motor ramping and direction/oscillation behavior
- Between-stage jar-change pause
- Startup/completion audio behavior
- Fault-state names

## Recovered source
`firmware/ui-demo/main.py` is the recovered source currently available. Its own header states: `Motor is NOT controlled in this version.`

## Still needed in repository
The later full motor-control firmware should be added when recovered from the Pico, development machine, backup, or prior source archive. The splash binary (`ponko_splash_rgb565.bin`) is also referenced by the UI-demo source but is not present in this recovered package.

## Physical project
Fabrication, assembly, and final checkout remain.
