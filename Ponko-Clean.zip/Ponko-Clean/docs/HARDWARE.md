# Hardware

## Core hardware
- Raspberry Pi Pico / RP2040
- BTS7960 H-bridge
- 12 V two-wire DC motor, ~300 RPM
- 12 V → 5 V buck converter
- ST7735S 160×128 SPI TFT
- Rotary encoder
- Green OK button
- Red E-Stop / Back button
- Piezo buzzer
- Four jar/basket positions

## Recovered UI-demo pinout
The recovered UI/demo source uses:
- GP0 — active buzzer via transistor
- GP10 — encoder S1
- GP11 — encoder S2
- GP12 — encoder push switch
- GP17 — TFT CS
- GP18 — TFT SCK
- GP19 — TFT MOSI/SDA
- GP20 — TFT RESET
- GP21 — TFT DC

The later project direction moved the piezo to GP4. Do not assume the UI-demo pinout is the final assembled-machine pinout.

## Display
ST7735-family 1.8-inch 160×128 SPI display, landscape orientation, rotated 90° clockwise. Backlight tied to VCC in the established build.
